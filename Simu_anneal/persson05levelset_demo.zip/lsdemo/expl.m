function expl

set(gcf,'rend','o');
set(gcf,'doublebuffer','on');

fF=inline('1+0*x','x','y');
fxinit=inline('.2*cos(phi)','phi','s');
fyinit=inline('.2*sin(phi)','phi','s');
lssim(fF,fxinit,fyinit,fxinit,fyinit,1e-2,70,'F=1');

fF=inline('x+y+1','x','y');
fxinit=inline('.2*cos(phi)-.5','phi','s');
fyinit=inline('.2*sin(phi)-.5','phi','s');
lssim(fF,fxinit,fyinit,fxinit,fyinit,2e-2,75,'F=x+y+1');

fF=inline('1+0*x','x','y');
fxinit=inline('[-.5+s; .5+0*s(1:end-2); .5-s; -.5+0*s(1:end-2)]','phi','s');
fyinit=inline('[-.5+0*s; -.5+s(2:end-1); .5+0*s; .5-s(2:end-1)]','phi','s');
lssim(fF,fxinit,fyinit,fxinit,fyinit,1e-2,40,'F=1');

fF=inline('-1+0*x','x','y');
fxinit=inline('[-.5+s; .5+0*s(1:end-2); .5-s; -.5+0*s(1:end-2)]','phi','s');
fyinit=inline('[-.5+0*s; -.5+s(2:end-1); .5+0*s; .5-s(2:end-1)]','phi','s');
lssim(fF,fxinit,fyinit,fxinit,fyinit,1e-2,40,'F=-1');

fF=inline('1+0*x','x','y');
fxinit1=inline('.2*cos(phi)-.5','phi','s');
fyinit1=inline('.2*sin(phi)','phi','s');
fxinit2=inline('.2*cos(phi)+.5','phi','s');
fyinit2=inline('.2*sin(phi)','phi','s');
lssim(fF,fxinit1,fyinit1,fxinit2,fyinit2,1e-2,50,'F=1');

function lssim(fF,fxinit1,fyinit1,fxinit2,fyinit2,dt,niter,tit)

n=20;
phi=2*pi*(0:n-1)'/n;
s=(0:n)'/n;

x1=fxinit1(phi,s);
y1=fyinit1(phi,s);
x2=fxinit2(phi,s);
y2=fyinit2(phi,s);

plot(x1([1:end,1]),y1([1:end,1]),'.-b',x2([1:end,1]),y2([1:end,1]),'.-b', ...
     'markersize',24,'linewidth',2)
axis equal,axis([-1,1,-1,1])
title(tit,'fontsize',24,'fontname','times','fontangle','italic');
pause

for iter=1:niter
  x11=x1([end,1:end,1]);
  y11=y1([end,1:end,1]);
  dx1=x11(3:end)-x11(1:end-2);
  dy1=y11(3:end)-y11(1:end-2);
  ds1=sqrt(dx1.^2+dy1.^2);
  
  F1=fF(x1,y1);
  x1=x1+dt*F1.*dy1./ds1;
  y1=y1+dt*F1.*(-dx1)./ds1;
  
  x21=x2([end,1:end,1]);
  y21=y2([end,1:end,1]);
  dx2=x21(3:end)-x21(1:end-2);
  dy2=y21(3:end)-y21(1:end-2);
  ds2=sqrt(dx2.^2+dy2.^2);
  
  F2=fF(x2,y2);
  x2=x2+dt*F2.*dy2./ds2;
  y2=y2+dt*F2.*(-dx2)./ds2;
  
  plot(x1([1:end,1]),y1([1:end,1]),'.-b',x2([1:end,1]),y2([1:end,1]),'.-b', ...
       'markersize',24,'linewidth',2)
  axis equal,axis([-1,1,-1,1])
  title(tit,'fontsize',24,'fontname','times','fontangle','italic');
  drawnow
end
pause
