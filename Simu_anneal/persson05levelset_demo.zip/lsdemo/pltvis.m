set(gcf,'rend','z');
colormap([.3,.3,1;.8,1,.8;0,0,0])

n=200;
A=inf*ones(n,n);

A(10,10)=1;
B0=fmm2d(A);

F=ones(n,n);
F(40:60,30:50)=0;

B=fmm2d(A,A,F);

V=double(B<B0+.1);
V(~F)=nan;
V(10,10)=nan;
V(isnan(V))=2;
V(1:2,:)=2; V(end-1:end,:)=2; V(:,1:2)=2; V(:,end-1:end)=2;
plt(V,2)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(findobj(gcf,'edgecol','k'),'edgecol','none')
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltvis1.eps

F(50:60,120:180)=0;

B=fmm2d(A,A,F);
V=double(B<B0+.1);
V(~F)=nan;
V(10,10)=nan;
V(isnan(V))=2;
V(1:2,:)=2; V(end-1:end,:)=2; V(:,1:2)=2; V(:,end-1:end)=2;
plt(V,2)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(findobj(gcf,'edgecol','k'),'edgecol','none')
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltvis2.eps

Vold=double(B<B0+.1);

A(10,10)=inf;
A(10,100)=1;
B=fmm2d(A,A,F);
B0=fmm2d(A);
V=double(Vold | (B<B0+.1));
V(~F)=nan;
V(10,10)=nan; V(10,100)=nan;
V(isnan(V))=2;
V(1:2,:)=2; V(end-1:end,:)=2; V(:,1:2)=2; V(:,end-1:end)=2;
plt(V,2)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(findobj(gcf,'edgecol','k'),'edgecol','none')
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltvis3.eps
