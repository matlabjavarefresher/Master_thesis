set(gcf,'rend','z');

A=inf*ones(100,100);
U=inf*ones(100,100);

A(10,10)=1;
U(10,10)=1;

B=fmm2d(A);
plt(B,50)
pause

F=ones(100,100);
F(40:60,40:60)=0;
plt(F)
pause

[B,U]=fmm2d(A,U,F);
B(isinf(B))=nan;
plt(B,50)
pause

F=ones(100,100);
F(40:60,40:60)=0.2;
plt(F)
pause

[B,U]=fmm2d(A,U,F);
plt(B,50)
pause
