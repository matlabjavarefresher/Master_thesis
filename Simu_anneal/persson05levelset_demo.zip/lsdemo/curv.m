function curv(reinit)

if nargin<1, reinit=0; end

h=0.025;
[xx,yy]=meshgrid(-1.1:h:1.1,-1.1:h:1.1);
p=[xx(:),yy(:)];

zz=reshape(dunion(dcircle(p,-.4,0,.5),dcircle(p,.4,0,.5)),size(xx));

for ii=1:60
  plt(xx,yy,zz)
  if ii==1, pause; end
  zz=curvevolve2d(zz,h,50);
  if reinit & mod(ii,5)==0
    zz=h*reinit2dc(zz/h,5,[.2,1.5]);
  end
end

for ii=1:30
  plt(xx,yy,zz)
  if ii==1, pause; end
  zz=h*reinit2dc(zz/h,5,[.2,1.5]);
end

function plt(xx,yy,zz)

surf(xx,yy,0*xx,zz),view(2),axis equal,shading interp,view(2)
hold on,contour(xx,yy,zz,-1:.1:1,'k');hold off
hold on,[foo,handle]=contour(xx,yy,zz,[0,0],'k');set(handle,'linewidth',2);hold off
drawnow
