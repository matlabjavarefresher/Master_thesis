function phi=curvevolve2d(phi,h,maxit,reinitnit)

[m,n]=size(phi); 
dt=1e-3*h;

upd=inf;
for ii=1:maxit
  kappa=kappa2d(phi,h);
  kappa=min(max(kappa,-20),20);
  upd=dt*kappa(2:m-1,2:n-1).*sqrt(((phi(3:m,2:n-1)-phi(1:m-2,2:n-1))/2/h).^2+ ...
                                  ((phi(2:m-1,3:n)-phi(2:m-1,1:n-2))/2/h).^2);
  phi(2:m-1,2:n-1)=phi(2:m-1,2:n-1)+upd;

%  disp(sprintf('%d %f',ii,max(abs(upd(:)))/dt));
end
