function d=dunion(d1,d2), d=min(d1,d2);
