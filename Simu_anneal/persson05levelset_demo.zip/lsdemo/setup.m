d0=fileparts([pwd,filesep]);
addpath([d0,'/lsutil']);
clear d0
