set(gcf,'rend','z');

A=inf*ones(100,100);

A(50,50)=1;
B=fmm2d(A);
plt(B)
pause

A(50,50)=inf;
A(50,25)=1;
A(30,75)=1;
B=fmm2d(A);
plt(B)
pause

A(25:75,75)=1;
B=fmm2d(A);
plt(B)
pause

U=zeros(size(A));
U(50,25)=1;
U(25:75,75)=2;
plt(U)
pause

[B,U]=fmm2d(A,U);
plt(B)
plt(U)
pause
