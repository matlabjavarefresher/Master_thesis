function plt(A,cont)

if nargin>=2
  contourf(A,cont)
else
  surf(A)
  shading interp
end

view(2)
axis equal
colorbar
