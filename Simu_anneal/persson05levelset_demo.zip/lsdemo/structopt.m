function structopt(icomp)

if nargin<1, icomp=1; end

h=0.025;
x=0:h:1;
y=0:h:1.5;
[xx,yy]=meshgrid(x,y);
[m,n]=size(xx);

phi=(.75/2-abs(yy-.75));
K=inteval(steph(phi,h),h)
rhos=[1,2];

ii=0;
while 1
  ii=ii+1;
 
  phi=step(phi,h,K,ii,rhos,icomp);
  contourf(x,y,phi,[-1e10,0]); axis equal
  drawnow
end

function I=inteval(i,h)

[m,n]=size(i);
I=h^2*sum(sum(i(1:m-1,1:n-1)+i(2:m,1:n-1)+i(1:m-1,2:n)+i(2:m,2:n)))/4;

function phi=step(phi,h,K,ii,rhos,icomp)

[m,n]=size(phi);
phi1=symextend(phi);

rho=rhos(1)+diff(rhos)*steph(phi,h);

[d,u1,u2]=eigprob(rho,h);
%fprintf('d=%8.4f\n',d(1));

if icomp==1
  cu=u1;
  cd=d(1);
else
  cu=u2;
  cd=d(2);
end

I1=rho.*cu.^2;
I1=h^2*sum(sum(I1(1:m-1,1:n-1)+I1(2:m,1:n-1)+I1(1:m-1,2:n)+I1(2:m,2:n)))/4;
v0=diff(rhos)*cd/I1*cu.^2;
v01=symextend(v0);

I2=delh(phi,h);
I3=v0.*I2;

I2=h^2*sum(sum(I2(1:end-1,1:end-1)+I2(2:end,1:end-1)+I2(1:end-1,2:end)+I2(2:end,2:end)))/4;
I3=h^2*sum(sum(I3(1:end-1,1:end-1)+I3(2:end,1:end-1)+I3(1:end-1,2:end)+I3(2:end,2:end)))/4;
if I2~=0
  nu=-I3/I2;
else
  nu=0;
end

v=v0+nu;

phi1=hjmov(phi,v,h);
%if abs(inteval(steph(phi1,h),h)-K)>1e-2
  nu=fminsearch(@err,nu,optimset('tolx',1e-8),phi,v0,h,K);
  phi1=hjmov(phi,v0+nu,h);
%end
phi=phi1;

if mod(ii,1)==0
  phi=h*reinit2dc(phi/h,1,[0.2,2]);
end

function e=err(nu,phi,v0,h,K)

phi1=hjmov(phi,v0+nu,h);
e=(inteval(steph(phi1,h),h)-K)^2;

function phi=hjmov(phi,v,h)

[m,n]=size(phi);
Dnx=zeros(m,n); 
Dpx=zeros(m,n); 
Dny=zeros(m,n); 
Dpy=zeros(m,n); 

for jj=1:1
  Dx=(phi(2:m,:)-phi(1:m-1,:))/h;
  Dy=(phi(:,2:n)-phi(:,1:n-1))/h;
  Dnx(2:m,:)=Dx;
  Dpx(1:m-1,:)=Dx;
  Dny(:,2:n)=Dy;
  Dpy(:,1:n-1)=Dy;

  dt=.9*h/max(v(:));
  delp=sqrt(max(Dnx,0).^2+min(Dpx,0).^2+max(Dny,0).^2+min(Dpy,0).^2);
  deln=sqrt(max(Dpx,0).^2+min(Dnx,0).^2+max(Dpy,0).^2+min(Dny,0).^2);
  phi=phi-dt*(max(v,0).*delp+min(v,0).*deln);
end

function s=steph(x,h)

s=(1/2+1/2*x/h+1/2/pi*sin(pi*x/h)).*(abs(x)<=h)+(x>h);

function d=delh(x,h)

d=1/2/h*(1+cos(pi*abs(x)/h)).*(abs(x)<=h);

function kappa=kappa2d(phi,h)

[m,n]=size(phi); 
phixx=(phi(3:m,2:n-1)-2*phi(2:m-1,2:n-1)+phi(1:m-2,2:n-1))/h^2;
phiyy=(phi(2:m-1,3:n)-2*phi(2:m-1,2:n-1)+phi(2:m-1,1:n-2))/h^2;
phixy=(phi(3:m,3:n)-phi(1:m-2,3:n)-phi(3:m,1:n-2)+phi(1:m-2,1:n-2))/(4*h*h);
phix=(phi(3:m,2:n-1)-phi(1:m-2,2:n-1))/(2*h);
phiy=(phi(2:m-1,3:n)-phi(2:m-1,1:n-2))/(2*h);
kappa=(phixx.*phiy.^2-2*phiy.*phix.*phixy+phiyy.*phix.^2)./(phix.^2+phiy.^2).^(3/2);

function v0kappa=v0kappa2d(phi,v0,h)

[m,n]=size(phi); 
phixx=(phi(3:m,2:n-1)-2*phi(2:m-1,2:n-1)+phi(1:m-2,2:n-1))/h^2;
phiyy=(phi(2:m-1,3:n)-2*phi(2:m-1,2:n-1)+phi(2:m-1,1:n-2))/h^2;
phixy=(phi(3:m,3:n)-phi(1:m-2,3:n)-phi(3:m,1:n-2)+phi(1:m-2,1:n-2))/(4*h*h);
phix=(phi(3:m,2:n-1)-phi(1:m-2,2:n-1))/(2*h);
phiy=(phi(2:m-1,3:n)-phi(2:m-1,1:n-2))/(2*h);

v0x=(v0(3:m,2:n-1)-v0(1:m-2,2:n-1))/(2*h);
v0y=(v0(2:m-1,3:n)-v0(2:m-1,1:n-2))/(2*h);
v0=v0(2:m-1,2:n-1);

v0kappa=(v0x.*phix.^3+v0x.*phix.*phiy.^2-2.*v0.*phix.*phiy.*phixy+v0.*phixx.*phiy.^2+v0y.*phiy.*phix.^2+v0y.*phiy.^3+v0.*phiyy.*phix.^2)./(phix.^2+phiy.^2).^(3/2);

function phi1=symextend(phi)

[m,n]=size(phi);
phi1=zeros(m+2,n+2);
phi1(2:end-1,2:end-1)=phi;
phi1(2:end-1,1)=phi(:,end);
phi1(2:end-1,end)=phi(:,1);
phi1(1,2:end-1)=phi(end,:);
phi1(end,2:end-1)=phi(1,:);
phi1(1,1)=phi(end,end);
phi1(end,end)=phi(1,1);
phi1(1,end)=phi(end,1);
phi1(end,1)=phi(1,end);
