function [d,u1,u2]=eigprob(rho,h)

[m,n]=size(rho);
m1=m-2; n1=n-2;

e=zeros(m,n);
e(2:m-1,2:n-1)=1;
e(find(e))=1:length(find(e));

ss=rho(2:m-1,2:n-1);
A=delsq(e)/h^2;
B=spdiags(ss(:),0,m1*n1,m1*n1);

[v,d]=eigs(A,B,2,0,struct('disp',0));
[d,ix]=sort(diag(d));

u1=zeros(m,n);
u1(2:m-1,2:n-1)=reshape(v(:,ix(1)),m1,n1);
u2=zeros(m,n);
u2(2:m-1,2:n-1)=reshape(v(:,ix(2)),m1,n1);
