set(gcf,'rend','z');

n=200;
A=inf*ones(n,n);

A(10,10)=1;
B0=fmm2d(A);
plt(B0)
pause

F=ones(n,n);
F(40:60,30:50)=0;
plt(F)
pause

B=fmm2d(A,A,F);
plt(B)
pause

V=double(B<B0+.1);
V(~F)=nan;
V(10,10)=nan;
plt(V)
pause

F(50:60,120:180)=0;
plt(F)
pause

B=fmm2d(A,A,F);
V=double(B<B0+.1);
V(~F)=nan;
V(10,10)=nan;
plt(V)
pause

Vold=double(B<B0+.1);

A(10,10)=inf;
A(10,100)=1;
B=fmm2d(A,A,F);
B0=fmm2d(A);
V=double(Vold | (B<B0+.1));
V(~F)=nan;
V(10,10)=nan; V(10,100)=nan;
plt(V)
pause
