set(gcf,'rend','z');

A=inf*ones(100,100);
U=inf*ones(100,100);

A(10,10)=1;
U(10,10)=1;

B=fmm2d(A);
plt(B,50)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltgeodes1.eps

F=ones(100,100);
F(40:60,40:60)=0;

[B,U]=fmm2d(A,U,F);
B(isinf(B))=nan;
plt(B,50)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltgeodes2.eps

F=ones(100,100);
F(40:60,40:60)=0.2;

[B,U]=fmm2d(A,U,F);
plt(B,50)
delete(findobj(gcf,'tag','Colorbar')),axis off
set(gcf,'paperpos',[0,0,8,8]);
print -p -depsc -r150 pltgeodes3.eps
